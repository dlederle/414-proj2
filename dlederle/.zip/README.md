Readme for the mysterious Project 2; CPSC 414 Networking

Works on rosemary, java 1.6
